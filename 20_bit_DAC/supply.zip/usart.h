/*
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (Revision 42):
 * Felipe Maimon wrote this file. As long as you retain this notice you
 * can do whatever you want with this stuff. If we meet some day, and you think
 * this stuff is worth it, you can buy me a beer in return.       Felipe Maimon
 * ----------------------------------------------------------------------------
 */

#ifndef _USART_H_
#define _USART_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#define USART_BAUD_RATE				19200UL
#define MY_UBRR						(((F_CPU / (USART_BAUD_RATE * 16UL))) - 1) 

/** Size of the circular receive buffer, must be power of 2 */
#define UART_RX_BUFFER_SIZE		8
#define UART_RX_BUFFER_MASK		( UART_RX_BUFFER_SIZE - 1)

/** Size of the circular transmit buffer, must be power of 2 */
#define UART_TX_BUFFER_SIZE 	4
#define UART_TX_BUFFER_MASK 	( UART_TX_BUFFER_SIZE - 1)

#define UART_PORT	PORTD
#define UART_DDR	DDRD
#define UART_PIN	PIND
#define RX			PD0
#define TX			PD1

#define AUTOBAUD

void 				uart_init(void);
char	 			uart_getc(void);
void 				uart_putc(unsigned char data);
void 				uart_puts(const char *s);
void				uart_puts_P(const char *s );
unsigned char		uart_rx_buffer_empty(void);

#endif
