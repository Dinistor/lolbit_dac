/*
 * Fonte.c
 *
 * Created: 12/03/2011 13:27:07
 *  Author: Felipe Maimon
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "usart.h"

uint32_t Out_Val;
volatile uint32_t pwm_accum;

ISR(TIMER0_OVF_vect) {
	
	OCR0A = (uint8_t) (pwm_accum >> 16) ;  // Output the top byte of my PWM accumulator to the PWM
	// since the PWM uses double buffering, this code will only reach
	// the PWM registers the next time the timer counter reaches 00.
	// This way, the PWM never changes in the middle of a PWM cycle - it only changes just as it is about to
	//     start a new cycle.
	pwm_accum &= 0x0000FFFFL ; // Delete the top byte leaving just the error
	pwm_accum +=  Out_Val ;  // Add the original intended value to the error in the accumulator for the next PWM cycle
}

void Init_PWM(void)
{
	Out_Val = 0;
	pwm_accum = 0;
	OCR0A = 0;
	
	// Fast PWM in OC0A, inverted
	TCCR0A = (1<<COM0A1)|(1<<COM0A0)|(1<<WGM00)|(1<<WGM01);
	
	// CLK = Fosc/1 = 20 MHz
	TCCR0B = (1<<CS00);

	// Enable timer 0 interrupt
	TIMSK = (1<<TOIE0);
	sei();
}


int main(void)
{
	char CurChar;
	char buffer[15];
	
	DDRB = (1<<PB2)|(1<<PB0);
	
	uart_init();
	Init_PWM();
	
    while(1)
    {
		CurChar = uart_getc();
		
		switch (CurChar)
		{
		case 'a':
			Out_Val += 0x00100000UL;
			break;
			
		case 's':
			Out_Val += 0x00010000UL;
			break;
			
		case 'd':
			Out_Val += 0x00001000UL;
			break;
			
		case 'f':
			Out_Val += 0x00000100UL;
			break;
			
		case 'g':
			Out_Val += 0x00000010UL;
			break;

		case 'h':
			Out_Val += 0x00000001UL;
			break;

		case 'z':
			Out_Val -= 0x00100000UL;
			break;
		
		case 'x':
			Out_Val -= 0x00010000UL;
			break;
		
		case 'c':
			Out_Val -= 0x00001000UL;
			break;
		
		case 'v':
			Out_Val -= 0x00000100UL;
			break;
		
		case 'b':
			Out_Val -= 0x00000010UL;
			break;

		case 'n':
			Out_Val -= 0x00000001UL;
			break;
		}
		
		Out_Val &= 0x00FFFFFF;
		
		ultoa(Out_Val, buffer, 10);
		uart_puts(buffer);
		uart_putc('!');
		uart_putc(13);
    }
}