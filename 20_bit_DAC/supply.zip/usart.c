/*
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (Revision 42):
 * Felipe Maimon wrote this file. As long as you retain this notice you
 * can do whatever you want with this stuff. If we meet some day, and you think
 * this stuff is worth it, you can buy me a beer in return.       Felipe Maimon
 * ----------------------------------------------------------------------------
 */

#include "usart.h"

static volatile unsigned char UART_RxBuf[UART_RX_BUFFER_SIZE];
static volatile unsigned char UART_TxBuf[UART_TX_BUFFER_SIZE];
static volatile unsigned char UART_TxHead;
static volatile unsigned char UART_TxTail;
static volatile unsigned char UART_RxHead;
static volatile unsigned char UART_RxTail;

void uart_init(void)
{
	uint16_t temp;
	
	// Setup port
	UART_PORT |= (1<<RX);
	UART_DDR |= (1<<TX);

    UART_RxHead = 0;
    UART_RxTail = 0;
    UART_TxHead = 0;
    UART_TxTail = 0;
    

#ifdef AUTOBAUD
	/*Auto baud rate*/
	TCCR1A = 0;
	TCCR1B = 0;
	TCNT1 = 0;

	/*wait for falling edge of start bit and then start timer*/
	while(UART_PIN & (1<<RX));
	TCCR1B |= (1<<CS10);

	/*wait for rising edge of start bit and then stop timer*/
	while(!(UART_PIN & (1<<RX)));
	TCCR1B &= ~(1<<CS10);
	
	temp = TCNT1;
	
	if (temp & (1<<3))
	{
		temp = temp >> 4;
	}
	else
	{
		temp = temp >> 4;
		temp--;
	}
	UBRRH = (uint8_t)(temp >> 8);
    UBRRL = (uint8_t)(temp);	

#else
    /*Set baud rate */
    UBRRH = (uint8_t)(MY_UBRR >> 8);
    UBRRL = (uint8_t)(MY_UBRR);
#endif

    /*Enable receiver and transmitter plus corresponding interrupts*/
    UCSRB = (1<<RXCIE)|(1<<RXEN)|(1<<TXEN);
    
    /* Set frame format: 8data, 1stop bit */
    UCSRC = (1<<UCSZ0) | (1<<UCSZ1);
}

/*************************************************************************
Function: uart_getc()
Purpose:  return byte from ringbuffer or wait for one if there is none
Returns:  received byte from ringbuffer
**************************************************************************/
char uart_getc(void)
{
    unsigned char tmptail;

	// Wait for new data
    while (UART_RxHead == UART_RxTail);
	
    /* calculate /store buffer index */
    tmptail = (UART_RxTail + 1) & UART_RX_BUFFER_MASK;
    UART_RxTail = tmptail; 

	// Just for debugging
//	uart_putc(UART_RxBuf[tmptail]);

    return UART_RxBuf[tmptail];
}

/*************************************************************************
Function: uart_putc()
Purpose:  transmit a byte via UART (wait for it to be avaiable if it isn't)
Input:    byte to be transmitted
Returns:  none          
**************************************************************************/
void uart_putc(unsigned char data)
{
    unsigned char tmphead;

    tmphead  = (UART_TxHead + 1) & UART_TX_BUFFER_MASK;
    
    while ( tmphead == UART_TxTail ){
        ;/* wait for free space in buffer */
    }
    
    UART_TxBuf[tmphead] = data;
    UART_TxHead = tmphead;
	
	UCSRB |= (1<<UDRIE);
}


/*************************************************************************
Function: uart_puts()
Purpose:  transmit string to UART
Input:    string to be transmitted
Returns:  none          
**************************************************************************/
void uart_puts(const char *s )
{
	while (*s) 
		uart_putc(*s++);
}


/*************************************************************************
Function: uart_puts_P()
Purpose:  transmit string from flash to UART
Input:    string to be transmitted
Returns:  none          
**************************************************************************/
void uart_puts_P(const char *s )
{
	while (pgm_read_byte(s) != 0x00)
		uart_putc(pgm_read_byte(s++));

}

/*************************************************************************
Function: uart_buffer_empty()
Purpose:  check if receive buffer is empty
Input:    none
Returns:  0 if RX buffer has data, 1 if RX buffer is emtpy
**************************************************************************/
unsigned char uart_rx_buffer_empty(void)
{
    if ( UART_RxHead == UART_RxTail ) {
        return 1;   /* no data available */
    }
	else {
		return 0;
	}
}/*uart_rx_buffer_empty*/


ISR(USART_RX_vect)
{
	unsigned char tmphead;
	unsigned char byte;
 
	/* read UART status register and UART data register */ 
	byte = UDR;
      
	/* calculate buffer index */ 
	tmphead = ( UART_RxHead + 1) & UART_RX_BUFFER_MASK;
    
	/* store new index */
	UART_RxHead = tmphead;
	/* store received data in buffer */
	UART_RxBuf[tmphead] = byte;
}

ISR(USART_UDRE_vect)
{
	unsigned char tmptail;

	/* if buffer NOT empty */
	if ( (UART_TxHead) != (UART_TxTail)) 
    {
        /* calculate and store new buffer index */
        tmptail = (UART_TxTail + 1) & UART_TX_BUFFER_MASK;
        UART_TxTail = tmptail;

        /* get one byte from buffer and write it to UART */
        UDR = UART_TxBuf[tmptail];  /* start transmission */
    }
	else
	{
		/* Disables TX Buffer Empty Interrupt */
		UCSRB &= ~(1<<UDRIE);
	}

}
